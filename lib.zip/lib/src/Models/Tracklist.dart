class Tracklist {
  String _title;
  bool isPlaying = false;
  String _preview;
  int _duration;
  String _imageUrlMusic;

  Tracklist(this._title, this._duration, this._preview);
  Tracklist.fromjson(Map<String, dynamic> json) {
    _title = json["title"];
    _duration = json["duration"];
    _preview = json["preview"];
    _imageUrlMusic = json["album"]["cover_small"];
  }
  setIsPlaying() {
    isPlaying = !isPlaying;
  }

  String get title => _title;
  int get duration => _duration;
  String get preview => _preview;
  String get imageMusic => _imageUrlMusic;

  Map<String, dynamic> TracklistToMap() {
    Map<String, dynamic> map = Map<String, dynamic>();
    map["title"] = this._title;
    map["duration"] = this._duration;
    map['preview'] = this._preview;
    map['album'] = this._imageUrlMusic;
        return map;
  }
}
