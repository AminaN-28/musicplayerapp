import 'package:musicaudioplayer/src/Models/Tracklist.dart';
import 'package:musicaudioplayer/src/utils/DatabaseHelper.dart';
import 'package:sqflite/sqflite.dart';

class Artist {
  String _name;
  String _img;
  String _tracklist;
  int _nbAlbum;
  List<Tracklist> artistTracklist = [];

  //"CREATE TABLE artiste (idArtist integer primary key autoincrement, name Text, picture_big Text)");

  Artist(this._name, this._img, this._nbAlbum, this._tracklist);
  Artist.fromjson(Map<String, dynamic> json) {
    _name = json["name"];
    _img = json["picture_big"];
    _tracklist = json["tracklist"];
    _nbAlbum = json["nb_album"];
  }
  String get name => _name;
  String get urlimage => _img;
  String get tracklist => _tracklist;
  int get nbalbum => _nbAlbum;

  /*Map<String, dynamic> toFromMap(Map<String, dynamic> map) {
    this._name = map["name"];
    this._img = map["picture_big"];
    this._tracklist = map["tracklist"];
  }*/

  /*Map<String, dynamic> toMap() {
    var map = new Map<String, dynamic>();
    map["name"] = name;
    map["picture_big"] = urlimage;
    map["tracklist"] = tracklist;

    return map;
  }*/

  Map<String,dynamic> ArtistToMap(){
    Map<String, dynamic> map = Map<String, dynamic>();
    map["name"] = this._name;
    map["picture_big"] = this._img;
   map["traclist"] = this._tracklist; 

    return map;
  
  }

  Artist.fromMap(Map<String, dynamic> map) {
    _name = map["name"];
    _img = map["picture_big"];
    //_tracklist = map["tracklist"];

  }

}
