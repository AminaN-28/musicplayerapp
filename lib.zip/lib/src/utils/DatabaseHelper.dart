import 'dart:io';

import 'package:musicaudioplayer/src/Models/Tracklist.dart';
import 'package:musicaudioplayer/src/Models/artist.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite/sqlite_api.dart';

import 'package:path/path.dart';

class DatabaseHelper {
  static Database _database;

  static Future<Database> get database async {
    print(
        '---------------------DATABASE GETTER CALLED-------------------------');
    if (_database == null) {
      Directory documentDirectory = await getApplicationDocumentsDirectory();
      //pour recuperer le dossier ou se trouve ts les fichiers de notre application
      String path = join(documentDirectory.path, "music.db");
      //path va directement pointer sur notre appplication
      return openDatabase(
        path,
        version: 1,
        onCreate: (Database db, int version) async {
          print('---------------DATABASE CREATED--------------');
          await db.execute(
              "CREATE TABLE artiste (name Text primary key, picture_big Text, tracklist Text)");
          //db.execute(
          // "CREATE TABLE tracklist (idTracklist integer primary key autoincrement,title Text, duration integer, preview Text, album Text,idArtist integer foreign key)");
        },
        /*onUpgrade: mettre a jour la version de la base*/
      );
    }
    return _database;
  }

  //Insertion avec rawInsert
  /*newArtist(Artist artist) async {
    final db = await database;
    var res = await db
        .rawInsert("INSERT Into artistTable (name,picture_big,tracklist)"
            " VALUES (${artist.name},${artist.urlimage}, ${artist.tracklist})");
    return res;
  }*/

static Future<void> insertArtist(Artist artist) async {
    var client = await database;
    //database cest le getteur qu'on a utilisé plus haut
    //on insere ce qu'on a mappe en faisaint appel a la methode ArtistToMap de
    //la classe Artist
    
    await client.insert("Artiste",artist.ArtistToMap());
  }


  insertTracklist(Tracklist tracklist) async {
    var client = await database;
    return client.insert("Tracklist", tracklist.TracklistToMap());
  }

//method for retrieve list of artists
//methode pour recuperer tous les artistes
  static Future<List<Artist>> get_All_Artits() async {
    var client = await database;

    var artist = await client
        .query("artiste", columns: ['name', 'picture_big', 'tracklist']);
    List<Artist> artistList = [];

    artist.forEach((currentArtist) {
      //faire appel a la methode de la class artist dans laquelle on a mappe

      Artist artiste = Artist.fromMap(currentArtist);

      //ajouter le map a la liste des artistes creer
      artistList.add(artiste);
    });
    //retourner la liste d'artiste
    return artistList;
  }

/*static Future<List<Map>> rechercheArtist() async {
        var client = await database;
        List<Map> resultat = await client.rawQuery("SELECT * FROM artiste ");
        return resultat;
      */

  /*static Future<List<Map>> selectArtist(String name) async {
        var client = await database;
        List<Map> resultat = await client.rawQuery("SELECT * FROM artiste where");
        return resultat;
      }*/
}


