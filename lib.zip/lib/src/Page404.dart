 import 'package:flutter/material.dart';
 class Page404 extends StatefulWidget {
   @override
   _Page404State createState() => _Page404State();
 }
 
 class _Page404State extends State<Page404> {
   @override
   Widget build(BuildContext context) {
     return Container(
       child: Text("ERREUR!!!!!!!!!!!!!"),

       
     );
   }
 }